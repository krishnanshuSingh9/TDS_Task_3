# HTML-RESTAURANT-WEBSITE
here we have a webpage for restaurant website by using html and css. We have applied simple transitions and animations to make the page look good.
